void PORT4_IRQHandler(void){

    // write this as part of Lab 5
    wasInterrupt = 1;   // tells main about an interrupt flag
    P4IFG       &= 0x00; // clear interrupt flags
 static uint16_t value_now = 0;
 uint16_t register_value = 0;
    register_value = P4IV;
    if (register_value == 0x02) { // Bumper 0 Hit
       value_now = value_now + 3;
       P4IFG    &= 0x00; // clear interrupt flags
    }
    if (register_value == 0x06) { // Bumper 1 Hit
       value_now = value_now + 2;
       P4IFG    &= 0x00; // clear interrupt flags
    }
    if (register_value == 0x08) { // Bumper 2 Hit
       value_now = value_now + 1;
       P4IFG    &= 0x00; // clear interrupt flags
    }
    if (register_value == 0x0C) { // Bumper 3 Hit
       value_now = value_now - 1;
       P4IFG    &= 0x00; // clear interrupt flags
    }
    if (register_value == 0x0E) { // Bumper 4 Hit
       value_now = value_now - 2;
       P4IFG    &= 0x00; // clear interrupt flags
    }
    if (register_value == 0x10) { // Bumper 5 Hit
       value_now = value_now - 3;
       P4IFG    &= 0x00; // clear interrupt flags
    }
    //value_now;
    //use P4IV register to know which button was pressed
    P4IFG &= ~0x01;  // clear interrupt flag in case it was active before
}