Yin Hinton ICA L23 HW Ints
P6SEL1 = 00; //GPIO
P6SEL0 = 00; //GPIO 

static NVIC -> ISER[1] = 00100; //enable port 6 interrupts 
#include <stdbool.h>
#include <stdint.h>
#include "..\inc\Clock.h"
#include "..\inc\CortexM.h"
#include "msp.h"
// Initialize Bump sensors
// Make six Port 4 pins inputs
// Activate interface pullup
// pins 7,6,5,3,2,0
// Interrupt on falling edge (on touch)

volatile uint8_t wasInterrupt = 0; // interrupt happened flag
void BumpInt_Init(void){
    // write this as part of Lab 5
    P6DIR |= 0xFF; // init as out; configure port four (Bumper Pins) as all outputs
                   // configure for a pull up
    P6REN |= 0xED; // enable pull resistor; is a pull down resistor when Out = 0, is pull up resistor when Out = 1
    P6OUT |= 0xED; // pull up pin
                   // allows pins to trigger interrupts
    P6IE  |= 0xED; // enable interrupts; configure bumper pins with the ability to trigger interrupts
    // PxIV = read only register?

    P6IES &= 0x01;  // trigger interrupt on falling edge; enable high to low edge triggered interrupt

    P6IFG &= ~0x01;  // clear interrupt flag in case it was active before
    NVIC -> ISER[1] = 0x00100; // enable port 6 interrupts
    //PORT4_IRQHandler();
}

// triggered on touch, falling edge
void PORT6_IRQHandler(void){

    // write this as part of Lab 5
    wasInterrupt = 1;   // tells main about an interrupt flag
    //P4IFG       &= 0x00; // clear interrupt flags
    static uint16_t pushCount = 0;
	uint16_t reg_value = 0;
	reg_value = P6IV;
    if (reg_value == 0x04) { //Push Button P6.1 pressed
       pushCount = ++pushCount;
	   if (pushCount == 10) {
		   P6OUT |= 0x01; // Sets LED on P6OUT to on
		   pushCount = 0;
	   }
       P6IFG    &= 0x00; // clear interrupt flags
    }
	if (reg_value == 0x0C) { //Push Button P6.5 pressed
		   P6OUT &= 0x00; // Sets LED on P6OUT to on
		   pushCount = 0;
	   }
       P6IFG    &= 0x00; // clear interrupt flags
    }
	
    //value_now;
    //use P4IV register to know which button was pressed
    P6IFG &= ~0x01;  // clear interrupt flag in case it was active before
}
// Good practice is to put main commands like setting the LED in a main file instead of the IRQ handler
