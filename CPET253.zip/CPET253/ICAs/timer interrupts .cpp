	   //counts 62500
	   //scale 24
	   //3Mhz clock
	   //cctl register to enable a timer interrupt
	   // In terms of ICAs look throughlectur notes for examples first
	   // with timer calculations start off with 12 MHz clk and assume n = 1 
	   // solve for counts to make sure its less than 65535 otherwise we need a clock scaler
#define LED1 BIT0
volatile bool wasInterrupt = false;
void PortInit(void) {
P1DIR  |=  LED1; //Create LED1 output
P1OUT  &= ~LED1; //turn off LED1 to start
P1SEL0 &= ~LED1; //select GPIO output
P1SEL1 &= ~LED1;

}	
void TA2_N_IRQHandler(void) {
	//reading the TA2IV register clears the hoghest priority flag
	uint16_t status = TA2IV;
	//set flag only if correct interrupt
	if (status == 0x0006) wasInterrupt = true;
}
void main(void) {
	WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
    DisableInterrupts();
    //Clock_Init48MHz(); initializing 48MHz clock would make counts too big
    PortInit();
    interruptInit();
	while(1) {
		if (wasInterrupt) {
			P1OUT ^= LED1; // toggles the LED1 = Port 1 Bit 0
			wasInterrupt = false; // clear flag
		}
	}
}
	