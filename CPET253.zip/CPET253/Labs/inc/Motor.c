// Motor.c
// Runs on MSP432
// Provide mid-level functions that initialize ports and
// set motor speeds to move the robot. Lab 13 solution
// Daniel Valvano
// July 11, 2019

/* This example accompanies the book
   "Embedded Systems: Introduction to Robotics,
   Jonathan W. Valvano, ISBN: 9781074544300, copyright (c) 2019
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/

Simplified BSD License (FreeBSD License)
Copyright (c) 2019, Jonathan Valvano, All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are
those of the authors and should not be interpreted as representing official
policies, either expressed or implied, of the FreeBSD Project.
*/

// Left motor direction connected to P5.4 (J3.29)
// Left motor PWM connected to P2.7/TA0CCP4 (J4.40)
// Left motor enable connected to P3.7 (J4.31)
// Right motor direction connected to P5.5 (J3.30)
// Right motor PWM connected to P2.6/TA0CCP3 (J4.39)
// Right motor enable connected to P3.6 (J2.11)

#include <stdint.h>
#include "msp.h"
#include "../inc/CortexM.h"
#include "../inc/PWM.h"

#define RIGHT_MOT_DIR      0x20     //p5.5 0b00100000 0b00010000
#define RIGHT_MOT_SLEEP    0x40     //p3.6
#define RIGHT_MOT_PWM      0x40     //p2.6
#define LEFT_MOT_DIR       0x10     //p5.4 0b00010000
#define LEFT_MOT_SLEEP     0x80     //p3.7
#define LEFT_MOT_PWM       0x80     //p2.7
// *******Lab 4 Solution*******

// ------------Motor_Init------------
// Initialize GPIO pins for output, which will be
// used to control the direction of the motors and
// to enable or disable the drivers.
// The motors are initially stopped, the drivers
// are initially powered down, and the PWM speed
// control is uninitialized.
// Input: none
// Output: none
void Motor_Init(void){
           //set direction pins as outputs
         //set sleep pins as outputs
         //set PWM pins as outputs
         P5DIR |= 0xFF; // configure port five (Direction Pins) as all outputs
         // When P5OUT is Set to 0, motor goes to forwards; When P5OUT is Set to 1, motor goes to backwards
         P3DIR |= 0xFF; // configure port three (Sleep Pins) as all outputs
         // When P3OUT is Set to 0, motor goes to sleep
         P2DIR |= 0xC0; // configure port two (PWM Pins) as all outputs
         // P2.6 and P2.7 are wired to TA0.3 and TA0.4 respectively, so we want to initialize those port directions as outputs
         // When P2OUT is Set to 0, motor doesn't move;  When P2OUT is Set to 1, motor does move;
         // Duty Cycle = (hightime/period)*100

         // Putting motors to sleep
         P3OUT |= ~0xC0;
    return;
}

// ------------Motor_Stop------------
// Stop the motors, power down the drivers, and
// set the PWM speed control to 0% duty cycle.
// Input: none
// Output: none
void Motor_Stop(void){
  // write this as part of Lab 4
      // Do I need to initialize the ports?
    P2OUT &= ~RIGHT_MOT_PWM & ~LEFT_MOT_PWM;       //stop motors
    P3OUT &= ~RIGHT_MOT_SLEEP & ~LEFT_MOT_SLEEP;   //put motors to sleep
    return;
}

// ------------Motor_Forward------------
// Drive the robot forward by running left and
// right wheels forward with the given duty
// cycles.
// Input: leftDuty  duty cycle of left wheel (0 to 14,998)
//        rightDuty duty cycle of right wheel (0 to 14,998)
// Output: none
// Assumes: Motor_Init() has been called
void Motor_Forward(uint16_t rightDuty, uint16_t leftDuty){ 
    //Run TimerA0 in PWM mode(any mode that isn't stop mode) with provided duty cycle
    //duty one and duty two are in units of us


    //where is TAxCCR0 set? in the cctl register? yess?
    //turn on PWM and set duty cycle
    //fixed period of 10ms
    //Set Motor Controls for forward

    //P5OUT = P5OUT & ~(RIGHT_MOT_DIR & LEFT_MOT_DIR);
    //P5OUT = P5OUT & ~(0b00100000 | 0b00010000); // why does this go backwards?
    //P5OUT = P5OUT & ~(0b00100000 & 0b00010000);
    //P5OUT = P5OUT & ~(RIGHT_MOT_DIR | LEFT_MOT_DIR);
    P5OUT &= ~0b00100000;
    P5OUT &= ~0b00010000;
    //motors forwards


    P3OUT = P3OUT | (RIGHT_MOT_SLEEP | LEFT_MOT_SLEEP);
    // wake up motors
    P2OUT = P2OUT | (RIGHT_MOT_PWM | LEFT_MOT_PWM);
    //drive pins high for PWM

    TA0CTL |= 0x0010;
    //changes the mode nibble to 01
    //control   bits 5 and 4 are mode control 00 to stop, 01 for up counting
    //          bits 7 and 6 are clock divider, where 01 = /2
    //          bits 9 and 8 choose clock source, where 10 = smclk
    TA0R = 0;
    //counter starts at zero once started
    TA0CCR3 = rightDuty; //14 999
    //Caputre/Compare 3 compare mode : holds value for comparison to timer TA0R
    //sets high time for right motor(P2.6 -> TA0.3 -> Right Motor)
    TA0CCR4 = leftDuty; //14 999
    //Caputre/Compare 4 compare mode : holds value for comparison to timer TA0R
    //sets high time for right motor(P2.7 -> TA0.4 -> Left Motor)
    return;  
}

// ------------Motor_Right------------
// Turn the robot to the right by running the
// left wheel forward with the given duty cycles.
// Input: leftDuty  duty cycle of left wheel (0 to 14,998)
//        rightDuty duty cycle of right wheel (0 to 14,998)
// Output: none
// Assumes: Motor_Init() has been called
void Motor_Right(uint16_t rightDuty, uint16_t leftDuty){ 
    //Run TimerA0 in PWM mode(any mode that isn't stop mode) with provided duty cycle
    //duty one and duty two are in units of us


    //where is TAxCCR0 set? in the cctl register? yess?
    //turn on PWM and set duty cycle
    //fixed period of 10ms
    //Set Motor Controls for forward

    P3OUT = P3OUT | (~RIGHT_MOT_SLEEP | LEFT_MOT_SLEEP);
    // wake up motors
    P5OUT = P5OUT & (RIGHT_MOT_DIR & LEFT_MOT_DIR);
    //motors forward
    P2OUT = P2OUT | (RIGHT_MOT_PWM | LEFT_MOT_PWM);
    //drive pins high for PWM

    TA0CTL |= 0x0010;
    //changes the mode nibble to 01
    //control   bits 5 and 4 are mode control 00 to stop, 01 for up counting
    //          bits 7 and 6 are clock divider, where 01 = /2
    //          bits 9 and 8 choose clock source, where 10 = smclk
    TA0R = 0;
    //counter starts at zero once started
    TA0CCR3 = rightDuty; //14 999
    //Caputre/Compare 3 compare mode : holds value for comparison to timer TA0R
    //sets high time for right motor(P2.6 -> TA0.3 -> Right Motor)
    TA0CCR4 = leftDuty; //14 999
    //Caputre/Compare 4 compare mode : holds value for comparison to timer TA0R
    //sets high time for right motor(P2.7 -> TA0.4 -> Left Motor)
    return;
}

// ------------Motor_Left------------
// Turn the robot to the left by running the
// the right wheel forward with the given duty cycles.
// Input: leftDuty  duty cycle of left wheel (0 to 14,998)
//        rightDuty duty cycle of right wheel (0 to 14,998)
// Output: none
// Assumes: Motor_Init() has been called
void Motor_Left(uint16_t rightDuty, uint16_t leftDuty){ 
    //Run TimerA0 in PWM mode(any mode that isn't stop mode) with provided duty cycle
    //duty one and duty two are in units of us


    //where is TAxCCR0 set? in the cctl register? yess?
    //turn on PWM and set duty cycle
    //fixed period of 10ms
    //Set Motor Controls for forward

    P3OUT = P3OUT | (RIGHT_MOT_SLEEP | ~LEFT_MOT_SLEEP);
    // wake up motors
    P5OUT = P5OUT & (RIGHT_MOT_DIR & LEFT_MOT_DIR);
    //motors forward
    P2OUT = P2OUT | (RIGHT_MOT_PWM | LEFT_MOT_PWM);
    //drive pins high for PWM

    TA0CTL |= 0x0010;
    //changes the mode nibble to 01
    //control   bits 5 and 4 are mode control 00 to stop, 01 for up counting
    //          bits 7 and 6 are clock divider, where 01 = /2
    //          bits 9 and 8 choose clock source, where 10 = smclk
    TA0R = 0;
    //counter starts at zero once started
    TA0CCR3 = rightDuty; //14 999
    //Caputre/Compare 3 compare mode : holds value for comparison to timer TA0R
    //sets high time for right motor(P2.6 -> TA0.3 -> Right Motor)
    TA0CCR4 = leftDuty; //14 999
    //Caputre/Compare 4 compare mode : holds value for comparison to timer TA0R
    //sets high time for right motor(P2.7 -> TA0.4 -> Left Motor)
    return;
}

// ------------Motor_Backward------------
// Drive the robot backward by running left and
// right wheels backward with the given duty
// cycles.
// Input: leftDuty  duty cycle of left wheel (0 to 14,998)
//        rightDuty duty cycle of right wheel (0 to 14,998)
// Output: none
// Assumes: Motor_Init() has been called
void Motor_Backward(uint16_t rightDuty, uint16_t leftDuty){ 
    //Run TimerA0 in PWM mode(any mode that isn't stop mode) with provided duty cycle
    //duty one and duty two are in units of us


    //where is TAxCCR0 set? in the cctl register? yess?
    //turn on PWM and set duty cycle
    //fixed period of 10ms
    //Set Motor Controls for forward

    P3OUT = P3OUT | (RIGHT_MOT_SLEEP | LEFT_MOT_SLEEP);
    // wake up motors
    //P5OUT = P5OUT | (RIGHT_MOT_DIR | LEFT_MOT_DIR);
    P5OUT = P5OUT | (0b00100000 | 0b00010000);
    //motors backwards
    P2OUT = P2OUT | (RIGHT_MOT_PWM | LEFT_MOT_PWM);
    //drive pins high for PWM

    TA0CTL |= 0x0010;
    //changes the mode nibble to 01
    //control   bits 5 and 4 are mode control 00 to stop, 01 for up counting
    //          bits 7 and 6 are clock divider, where 01 = /2
    //          bits 9 and 8 choose clock source, where 10 = smclk
    TA0R = 0;
    //counter starts at zero once started
    TA0CCR3 = rightDuty; //14 999
    //Caputre/Compare 3 compare mode : holds value for comparison to timer TA0R
    //sets high time for right motor(P2.6 -> TA0.3 -> Right Motor)
    TA0CCR4 = leftDuty; //14 999
    //Caputre/Compare 4 compare mode : holds value for comparison to timer TA0R
    //sets high time for right motor(P2.7 -> TA0.4 -> Left Motor)
    return;
}

void TimerInit(void){
    // working in the timer a 0 (TA0) control register
    //initialize TimerA0 for PWM
    //Since the motors are connected to P2.6 and P2.7, use TimerA0, compare blocks 3 and 4
    //?????
    // PxSEL in this configuration says we're using port 2's primary module function instead of the general purpose I/O
    P2SEL1 &= 0x3F;
    P2SEL0 |= 0xC0;
    

    TA0CTL = 0x0240; 
    //Bits 15 - 12 Reserved
    //Bits 11 - 10 Reserved
    //Bits 9 - 8 TASSEL = 0b10; select smclk as source
    //Bits 7 - 6 ID = 0b01; input divider set to 2
    //Bits 5 - 4 TAMC = 0b00; select mode as stop timer
    //Bits 3 - 0 Not yet covered; ignore using zeroes

    TA0CCR0 = 59999;  //number of counts for 0.25 seconds
    TA0CCTL3 |= 0x00E0; //output mode 7 reset/set
    TA0CCTL4 |= 0x00E0; //output mode 7 reset/set
    TA0CCR3 = 14999; //15 000 counts for a 25% duty cycle
    TA0CCR4 = 14999; //15 000 counts for a 25% duty cycle
    TA0CTL |= 0x0010; //set timer to up mode; starts timer
  return;
}

void Delay_Xms(){
    //working example for 0.1s, 100 ms
    TA1CTL &= ~0x0030;                      //stop the timer
    TA1CTL |= 0x0200; TA1CTL &= ~0x0100;    //choose smclk for clock source
    TA1CTL |= 0x0080;                       //choose clock divider of 4; ID = 10
    TA1EX0 |= 0x0004;                       //choose second clock divider of 5 for a total divison of 20
    TA1EX0 &= ~0x0003;                      //sets zeroes in the divider value
    TA1CCR0 = 59999;                        //number of counts for 0.25 seconds
    TA1R   = 0;                             //clear timer
    TA1CTL |= 0x0010;                       //set timer for up mode; statrs the timer
    while (!(TA1CCTL0 & 0x0001)) {}         //wait for flag to know time is up
    TA1CCTL0 &= ~0x0001;                    //clear the flag
    TA1CTL   &= ~0x0030;                    //stop the timer

    TA1CTL = 0x0280;
    TA1EX0  = 0x0004;
    TA0CCR0 = 59999;// 0 to 59 999 = 60 000 counts
    //Period of a 10ms clock based on timer PWM calculations
    //Caputre/Compare 0 compare mode : holds value for comparison to timer TA0R
    //sets period for PWM
}
