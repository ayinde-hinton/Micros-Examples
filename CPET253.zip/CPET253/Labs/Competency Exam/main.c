/*   DESIGNER NAME:  Yin Hinton
   ASSIGNMENT NAME:  Competency Exam
         FILE NAME:  Competency Exam main.c
         Section  :  1

 Functions in this code:

*/
#include "msp.h"
#include <stdint.h>
#include <stdbool.h>
#include "..\inc\Clock.c"
#include "..\inc\CortexM.c"
/**
 * main.c
 */
void PortInit (void)
{
//This function sets the motor pins as outputs and puts the motors to sleep
    // REMEBER C starts with 0 ends with 7

    //P1DIR &= 0xFD;
    P5DIR |= 0x40; // set pin two to output
    P1DIR &= ~0x02; //set pin one to input
    P1REN |= 0x02; // gets pin ready for a pull up/down resistor
    P1OUT |= 0x02; // gives pin a pull up resistor

    return;
}
void TimerInit(void)
{
    // sets port 5.6 to timer 2.1
    P5SEL1 &= ~0x40; //Position = Pin; Value = 1 or 0
    P5SEL0 |= 0x40;  //Position = Pin; Value = 1 or 0

    TA2CTL = 0x02C0;
    //Bits 15 - 12 Reserved
    //Bits 11 - 10 Reserved
    //Bits 9 - 8 TASSEL = 0b10; select smclk as source
    //Bits 7 - 6 ID = 0b01; input divider set to 2
    //Bits 5 - 4 TAMC = 0b00; select mode as stop timer
    //Bits 3 - 0 Not yet covered; ignore using zeroes

    TA2CCR0 = 33333;  //number of counts for 0.009 seconds
    TA2CCTL1 |= 0x00E0; //output mode 7 reset/set
    TA2CCR1 = 20000; //15 000 counts for a 25% duty cycle

  return;
}

void main(void)
{
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
    Clock_Init48MHz();
    PortInit();
    TimerInit();
    while(1) {
        // zero means active low
        // P1OUT is query bit masked with all zeros an a one on the bit we're concerned with checking
            if (0 == (P1IN & 0x02)) {
                TA2CTL |= 0x0010; //set timer to up mode; starts timer
                P5OUT |= 0x40;
                //P1OUT ^= 0x20;
            }
            while (0 == (P1IN & 0x02));
        TA2CTL &= 0x02C0; //set timer to stop mode; stops timer
    }
    //return;
}
// use |= to set ones
// use &= to set zeroes
// how does PSEL count?

