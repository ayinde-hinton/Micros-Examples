//------------See AP.c for details of hardware connections to CC2650--------------------
//------------See LaunchPad.c for details of switches and LEDs--------------------------

#include <stdint.h>
#include <stdbool.h>
#include "../inc/Clock.h"
#include "../inc/CortexM.h"
#include "../inc/AP.h"
#include "../inc/UART0.h"
#include "../inc/UART1.h"
#include "../inc/SSD1306.h"
#include "../inc/Motor.h"
#include "msp.h"


uint8_t  BT_ByteData;      // 8-bit user data from the phone
volatile enum motor_states {idle, PattA, PattB, Clean, Stop} prevState, state;

// ********OutValue**********
// Debugging dump of a data value to virtual serial port to PC
// data shown as 1 to 8 hexadecimal characters
// Inputs:  response (number returned by last AP call)
// Outputs: none
void ValueOut(char *label,uint32_t value){
  UART0_OutString(label);
  UART0_OutUHex(value);
}

void MoveRobot (uint8_t command) {
// this function calls the appropriate functions to stop, move forward, move backward, turn right,
// or turn left according to the command received from the BLE

       //These are the four states of the state machine
       //should there be an idle state also???
       //enum motor_states {idle, PattA, PattB, Clean, Stop} state;
       // woudl state need to be enumerated also; is mixing types a bad thing?
       state = idle;            //start state
       //prevState = !idle;       //used to know when the state has changed
       //uint16_t stateTimer = 0;       //used to stay in a state

       //bool isNewState;           //true when the state has switched

       //through this while loop, every time one of the motor functions is called
       //it takes 10ms. Assume that the delay in each state is 10ms
       //time spent in any direction = stateTimer * 10ms

           AP_BackgroundProcess();//this isnt'fixing the data going stale
           //look at where bluetooth is queried
           // try putting it at this point of the while loop to make sure query is refreshed
           //isNewState = (state != prevState);
           //prevState = state;  //save state for next time
          switch (state) {
          //each case below should have entry housekeeping, state business and exit housekeeping
          //remember to reset the stateTimer each time you enter a new state
          //you must assign a new state when stateTer reaches the correct value
          //AP_BackgroundProcess();
          case idle:
              Motor_Stop();
              // exit condition/housekeeping
              if (command == 1) {
                SSD1306_Clear();
                SSD1306_SetCursor(0,0);
                SSD1306_OutString("Blend Pattern A");
                SSD1306_OutChar(CR);
                state = PattA;
              }
              else if (command == 2){
                SSD1306_Clear();
                SSD1306_SetCursor(0,0);
                SSD1306_OutString("Blend Pattern B");
                SSD1306_OutChar(CR);
                state = PattB;
              }
              else if (command == 3){
                SSD1306_Clear();
                SSD1306_SetCursor(0,0);
                SSD1306_OutString("Clean");
                SSD1306_OutChar(CR);
                state = Clean;
              }
              else if (command == 4){
                SSD1306_Clear();
                SSD1306_SetCursor(0,0);
                SSD1306_OutString("Stop");
                SSD1306_OutChar(CR);
                state = Stop;
              }
              break;
              } //state

}

void WriteByteData(void){ // called on a SNP Characteristic Write Indication on characteristic ByteData
  MoveRobot(BT_ByteData);   // send command to robot
  ValueOut("\n\rWrite BLE_ByteData=",BT_ByteData);
}


int main(void){
  volatile int r;

  DisableInterrupts();
  Clock_Init48MHz();
  UART0_Init();
  //UART1_Init();
  Timer_Init();
  Motor_Init();
  SSD1306_Init(SSD1306_SWITCHCAPVCC);
  EnableInterrupts();
  UART0_OutString("\n\rApplication Processor - MSP432-CC2650\n\r");
  r = AP_Init();
  AP_GetStatus();  // optional
  AP_GetVersion(); // optional
  AP_AddService(0xFFF0);
  //------------------------
  BT_ByteData = 0;  // write parameter from the phone will be used to control direction
  AP_AddCharacteristic(0xFFF1,1,&BT_ByteData,0x02,0x08,"DirectionData",0,&WriteByteData);

  //------------------------

  AP_RegisterService();
  AP_StartAdvertisementJacki();
  AP_GetStatus(); // optional
  while(1){
    AP_BackgroundProcess();  // handle incoming SNP frames
    // added to make sure moveRobot(); gets called again, doesn't look like its working as intended based on the debugger.
    //AP_AddCharacteristic(0xFFF1,1,&BT_ByteData,0x02,0x08,"DirectionData",0,&WriteByteData);
    ////????


    //state = Stop;            //start state
    prevState = !idle;       //used to know when the state has changed
    uint16_t stateTimer = 0;       //used to stay in a state

    bool isNewState = false;           //true when the state has switched
    switch (state) {
          case PattA:
              if(isNewState){
                  stateTimer = 0;
              }
              Motor_Forward(0, 14950);
              Clock_Delay1ms(200);
              Motor_Backward(0, 14950);
              Clock_Delay1ms(200);
              Motor_Forward(0, 14950);
              Clock_Delay1ms(200);
              Motor_Backward(0, 14950);
              stateTimer++;
              if (stateTimer >= 5) {
                state = idle;
              }
              break;

          case PattB:
              if(isNewState){
                  stateTimer = 0;
              }
              //fast
              Motor_Forward(0, 14950);
              ++stateTimer;
              //slow
          if (stateTimer >= 5) {
            Motor_Forward(0, 7950);
            ++stateTimer;
            if (stateTimer >= 10) {
                Motor_Forward(0, 14950);
                ++stateTimer;
              if (stateTimer >= 15) {
                Motor_Forward(0, 7950);
                ++stateTimer;
                  if (stateTimer >= 20) {
                      state = idle;
                    }
                  }
                }
              }
              break;

          case Clean:
            //Do PattB Here
              if(isNewState){
                  stateTimer = 0;
              }
              //fast
              Motor_Forward(0, 18950);
              ++stateTimer;
              //slow
          if (stateTimer >= 2) {
            Motor_Forward(0, 7950);
            ++stateTimer;
            if (stateTimer >= 4) {
                Motor_Forward(0, 18950);
                ++stateTimer;
              if (stateTimer >= 6) {
                Motor_Forward(0, 7950);
                ++stateTimer;
                  if (stateTimer >= 8) {
                      Motor_Forward(0, 18950);
                      ++stateTimer;
                      if (stateTimer >= 10) {
                        state = idle;
                      }
                    }
                  }
                }
              }
              break;

          case Stop:
              Motor_Stop();
              state = idle;
              break;

          default:
              state = idle;
           // return;
          } //switch
           Delay_Xms();
           P3DIR |= 0x01;
           P3OUT ^= 0x01;

  }
}

