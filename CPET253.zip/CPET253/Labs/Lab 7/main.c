#include <stdbool.h>
#include "msp.h"
#include "..\inc\Reflectance.h"
#include "..\inc\Motor.h"
#include "..\inc\Clock.h"

/**
 * main.c
 */
void main(void)
{
    WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
    Timer_Init();
    Motor_Init();
    Clock_Init48MHz();
    Reflectance_Init();
    //while(1){
	//int32_t average = Reflectance_Position(Reflectance_Read(1100));

    enum motor_states {idle, slowRight, slowLeft} state, prevState;

    state = idle;            //start state
    prevState = !idle;       //used to know when the state has changed
    //uint16_t stateTimer = 0;       //used to stay in a state

    bool isNewState;           //true when the state has switched
	// !!!try putting while(1) here!!!
    while(1) {
        int32_t average = Reflectance_Position(Reflectance_Read(1100));
            isNewState = (state != prevState);
            prevState = state;  //save state for next time

           switch (state) {
           case idle:
               Motor_Forward(7500, 7000);
               // exit condition/housekeeping
               /*if (-24 < average < 24) {
                 state = idle;
               }
               else
               invalid check, need to separate the compares; also it stays in the idle state by default so no need
               */
               average = Reflectance_Position(Reflectance_Read(1100));
               if (average <= -48) {
                 state = slowLeft;
               }
               else {
                 state = slowRight;
               }
               break;

           case slowLeft:
               if(isNewState){
                 Motor_Forward(7000, 4000);
                 //stateTimer = 0;
                 average = Reflectance_Position(Reflectance_Read(1100));
               }
               if (average <= -48) {
                 state = slowLeft;
               }
			   else {
				state = idle;
			   }
               break;

           case slowRight:
               if(isNewState){
                 Motor_Forward(4500, 7000);
                 //stateTimer = 0;
                 average = Reflectance_Position(Reflectance_Read(1100));
               }
               if (average >= 48) {
                 state = slowLeft;
               }
			   else {
				state = idle;
			   }
               break;

           default:
               state = idle;
            // return;
           } //switch
            Clock_Delay1ms(100);
            P3DIR |= 0x01;
            P3OUT ^= 0x01;
       } // state machine
    }
//}
