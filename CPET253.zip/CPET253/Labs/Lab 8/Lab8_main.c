#include "msp.h"
#include <msp432.h>
#include <stdint.h>
#include <stdbool.h>
#include "../inc/Clock.h"
#include "../inc/CortexM.h"
#include "../inc/Motor.h"

#define TRIGGER 0x04
#define ECHO 0x08

#define microsecondsToClockCycles(a) ( (a) * 1.5 )       //assume 12Mhz clock divided by 8
#define clockCyclesToMicroseconds(a) ( (a) / 1.5 )       // 1.5 clock cycles = 1us

void TimerInit(void);
void Servo(uint16_t angle);
uint32_t pulseIn (void);

void UltraSonicInit(void)
{
    P6DIR |= 0x04 ;       //make P6.2 an output for US trigger
    P6DIR &= ~0x08;       //make P6.3 an input for US echo
    ;       //put both pins in normal mode
    ;
    return;
}
void ServoInit(void)
{
    P8DIR |= 0x04;     //make P8.2 an output : output from Timer3.2
    P8SEL1 &= 0x00;     //set SEL1 and SEL0 for pwm function
    P8SEL0 |= 0x04;
    Servo();     //call Servo() function to center servo
    Clock_Delay1ms(50);     //delay here to give servo time to move
    ;     //stop the timer
    return;
}
void Servo(uint16_t angle_count)
{
    ;     //use Timer A3??? //set period for 20ms
    ;      //set high time for the input angle
    ;      //set timer for up mode 
    return;
}
uint16_t distanceInCm(void) {
    uint16_t distance;

    ;      //drive trigger pin high
    Clock_Delay1us(10);      //wait 10 us
    ;      //drive trigger pin low
    distance = pulseIn() * 0.034/2;      //calculate distance using s=t * 0.034/2. t comes from pulseIn() function
    if (distance = 0){
        ;      // if no echo (distance = 0), assume object is at farthest distance
    }
    return distance;      //return the distance
}
uint32_t pulseIn (void)
{
    uint16_t width = 0;
    uint16_t time = 0;
    uint16_t maxcount = 56999;  //max count for 38 ms (timeout)
    TA2CTL |= 0x0020;           //set timer for continuous mode

    ;                   //reset the count
                        //wait for the pulse to start (while Echo is low)
                        //if count is greater than maxcount return 0
    ;

    ;                   //reset the count
                        //wait for the pulse to finish (while Echo is high)
                        //if count is greater than maxcount return 0
    ;

    reading =;               //read the count (width of the return pulse)
    ;               //stop the timer
    reading_in_us = ;               // convert the reading to microseconds.
    return reading_in_us;               //return the microsecond reading
}

void main(void)
{

    uint16_t distance, right_wall, left_wall;

	WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;		// stop watchdog timer
	Clock_Init48MHz();  // makes bus clock 48 MHz
	Motor_Init();
	TimerInit();
	UltraSonicInit();
	ServoInit();

	//These are the states of the state machine
	enum motor_states {FORWARD, BACKWARD, RIGHT, LEFT, SWEEP_RIGHT, SWEEP_LEFT} state, prevState;

	state = FORWARD;          //start in FORWARD state
	prevState = !FORWARD;   //used to know when the state has changed
	uint16_t stateTimer = 0;           //used to stay in a state
	bool isNewState;              //true when the state has switched


	while(1) {

	    isNewState = (state != prevState);
            prevState = state;
	    distance = distanceInCm();  //this needs to be moved to the states that use it

	    switch (state) {
            } 
        Clock_Delay1ms(20);
	} //while
}
