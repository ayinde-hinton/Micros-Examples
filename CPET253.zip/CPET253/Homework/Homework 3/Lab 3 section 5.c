// OPEN NEW ARDUINO SKETCH.
// CLICK IN THIS TEXT BOX. CTRL-A, CTRL-C.
// CLICK IN SKETCH. CTRL-A, CTRL-V.

// Lab 1 A level starter: Cook stats

const int TOTAL_SAMPLES = 600; // simulated samples
int numSamples = 1;
float sample, runningMean = 0.0, runningVar = 0.0, stdev = 0.0;

//**********************************************************************
void setup()
{
  Serial.begin(9600);
 
// This line tells MATLAB that the Arduino is ready to accept data
  Serial.println("%Arduino Ready");  

// Wait until MATLAB sends a 'g' to start sending data
while (Serial.read() != 'g'); // spin until 'g' entry

}

//**********************************************************************
void loop()
{ 
  sample = simSample();
  calculateStats();
  displayStatsData();
  if (++numSamples > TOTAL_SAMPLES) while (true);
  
} // loop()

//**********************************************************************
float simSample(void)
{
  // Simulate sensor for stats calculation development
  float simSmpl, simAmp = 1.0, simT = 60;
  
  //simAmp = ((numSamples > 180) && (numSamples < 300)) ? 0.125 : 1.0; // burst amplitude
  //simT = ((numSamples > 180) && (numSamples < 300)) ? 30.0 : 60.0; // burst frequency
  simSmpl = 180.0 + simAmp*sin((numSamples/simT)*TWO_PI); // fixed amplitude, frequency
  
  return simSmpl; 
}
//**********************************************************************
void calculateStats(/*void*/ float xi)
{
  // Calculate running statistics per Cook pseudo code.
  static int tick = 1;
  static float oldMean, oldVar, Mean, Variance;
  if (tick == 1){
    Mean = xi;
    runningVar = 0;
    Variance = 0;
    //sets up for next variation
    oldMean = runningMean;
    oldVar = runningVar;
  } else {
    runningMean = oldMean + (xi-oldMean) / tick;
    runningVar = oldVar + (xi-oldMean) * (xi-runningMean);
    Variance = runningVar/(tick-1);
    //set up fpr next itteration
    oldMean = runningMean;
    oldVar = runningVar;
  }
}
//**********************************************************************
void displayStatsData(void)
{
  // Display results to console
  if (numSamples == 1)
  {
    Serial.print("\nn\tsmpl\trunningMean\tstdev\n");
  }
  Serial.print(numSamples);  Serial.print('\t');
  Serial.print(sample); Serial.print('\t');
  Serial.print(runningMean);   Serial.print('\t');
  Serial.print(runningVar);  Serial.print('\n');  
}
