/*   DESIGNER NAME:  Yin Hinton, Shams Bellal, Kenny Nelson <We need to check in>, <Adam Zhang; we need to connect>
   ASSIGNMENT NAME:  Homework3
         FILE NAME:  Homework3_1_v01

 To control the motors on the TI-RSLK robot, there are three outputs that need
 to be driven.
    :Pin    :Description            :Notes
    :=======:=======================:=========================
    : P5.5  : Right motor direction : 0=forwards, 1=backwards
    : P3.6  : Right motor sleep     : 0=sleep, 1=awake
    : P2.6  : Right motor PWM       : 0=stop, PWM signal = go
    : P5.4  : Left motor direction  : 0=forwards, 1=backwards
    : P3.7  : Left motor sleep      : 0=sleep, 1= awake
    : P2.7  : Left motor PWM        : 0=stop, PWM signal = go

 Functions in this code:
     -MotorForward(void) - set both motors to forward, use SysTick to create PWM
      with 10 ms period and 25% duty cycle
     -MotorBackward(void) - set both motors to backward, use SysTick to create PWM
      with 10 ms period and 25% duty cycle
     -MotorTurnRight(void) - set left motor to forward and right motor to sleep,
      use SysTick to create PWM with 10 ms period and 25% duty cycle
     -MotorTurnLeft(void) - set right motor to forward and left motor to sleep,
      use SysTick to create PWM with 10 ms period and 25% duty cycle
      
  Altered Lab 3 Code to adjust pwm timer based on variable input 
*/

dataType pwmHighTime // enter time in ms for signal to be high; how to make variable?
dataType pwmLowTime  // enter time in ms for signal to be low; how to make variable?
void MotorForward (pwmHighTime, pwmLowTime)
//This function is used to drive both motors in the forward direction.
//It uses SysTick to create a PWM wave with a period of 10ms and 25% duty cycle
//The PWM signal is high for 2.5 ms and low for 7.5 ms
//Each time this function is called, one cycle of the PWM is output on the PWM pin
{
     P3OUT |= RIGHT_MOT_SLEEP | LEFT_MOT_SLEEP;  //wake up motors
     //P3OUT = P3OUT | (RIGHT_MOT_SLEEP | LEFT_MOT_SLEEP);
     //What is this starting off as? Doesn't Matter because anding?
     P5OUT &= ~RIGHT_MOT_DIR & ~LEFT_MOT_DIR;  //motors forward
     //P5OUT = P5OUT & ~(RIGHT_MOT_SLEEP & LEFT_MOT_SLEEP);
     P2OUT |= RIGHT_MOT_PWM | LEFT_MOT_PWM;  //drive pins high for PWM
     // wait high time
     // since the clock is 48Mhz, every 48 counts is 1 us
     // high time of 2500 us is 25% duty cycle
         SysTick -> LOAD = 48 * (pwmHighTime * 1000);  
         SysTick -> VAL = 0;           //clear the count to 0
         SysTick -> CTRL = 0x00000005; //enable the timer
         while (!(SysTick -> CTRL & 0x00010000)); //wait for flag that time is up
     P2OUT &= ~RIGHT_MOT_PWM & ~LEFT_MOT_PWM;  //drive pins low for PWM
         // now low time
         SysTick -> LOAD = 48 * (pwmLowTime * 1000);  
         SysTick -> VAL = 0;
         SysTick -> CTRL = 0x00000005;
         while (!(SysTick -> CTRL & 0x00010000));
     return;
}
//Period = T = 10ms
void MotorBackward (pwmHighTime, pwmLowTime)
{
     P3OUT |= RIGHT_MOT_SLEEP | LEFT_MOT_SLEEP;  //wake up motors
     //removed the inversion to change direction???
     P5OUT &= RIGHT_MOT_DIR & LEFT_MOT_DIR;  //motors backward
     P2OUT |= RIGHT_MOT_PWM | LEFT_MOT_PWM;  //drive pins high for PWM
     // wait high time
     // since the clock is 48Mhz, every 48 counts is 1 us
     // high time of 2500 us is 25% duty cycle
         SysTick -> LOAD = 48 * (pwmHighTime * 1000);  //2500us = 2.5ms
         SysTick -> VAL = 0;           //clear the count to 0
         SysTick -> CTRL = 0x00000005; //enable the timer
         while (!(SysTick -> CTRL & 0x00010000)); //wait for flag that time is up
     P2OUT &= ~RIGHT_MOT_PWM & ~LEFT_MOT_PWM;  //drive pins low for PWM
         // now low time
         SysTick -> LOAD = 48 * (pwmLowTime * 1000);  //7.5ms
         SysTick -> VAL = 0;
         SysTick -> CTRL = 0x00000005;
         while (!(SysTick -> CTRL & 0x00010000));
     return;
}
void MotorTurnLeft (pwmHighTime, pwmLowTime)
{
     P3OUT |= RIGHT_MOT_SLEEP | ~LEFT_MOT_SLEEP; //wake up motors
     P5OUT &= ~RIGHT_MOT_DIR;  //motors forward
     P2OUT |= RIGHT_MOT_PWM;  //drive pins high for PWM
     // wait high time; wait for PWM to go high??
     // since the clock is 48Mhz, every 48 counts is 1 us
     // high time of 2500 us is 25% duty cycle; T = 10ms???
         SysTick -> LOAD = 48 * (pwmHighTime * 1000);  //1250us = 1.25ms
         SysTick -> VAL = 0;           //clear the count to 0
         SysTick -> CTRL = 0x00000005; //enable the timer
         while (!(SysTick -> CTRL & 0x00010000)); //wait for flag that time is up
     P2OUT &= ~RIGHT_MOT_PWM;  //drive pins low for PWM
         // now low time
         SysTick -> LOAD = 48 * (pwmLowTime * 1000);  //8.75ms
         SysTick -> VAL = 0;
         SysTick -> CTRL = 0x00000005;
         while (!(SysTick -> CTRL & 0x00010000));
     return;
}
void MotorTurnRight (pwmHighTime, pwmLowTime)
{
     P3OUT |= ~RIGHT_MOT_SLEEP | LEFT_MOT_SLEEP;  //wake up motors
     P5OUT &= ~LEFT_MOT_DIR;  //motors forward
     P2OUT |= LEFT_MOT_PWM;  //drive pins high for PWM
     // wait high time
     // since the clock is 48Mhz, every 48 counts is 1 us
     // high time of 2500 us is 25% duty cycle
         SysTick -> LOAD = 48 * (pwmHighTime * 1000);  //1250us = 1.25ms
         SysTick -> VAL = 0;           //clear the count to 0
         SysTick -> CTRL = 0x00000005; //enable the timer
         while (!(SysTick -> CTRL & 0x00010000)); //wait for flag that time is up
     P2OUT &= ~LEFT_MOT_PWM;  //drive pins low for PWM
         // now low time
         SysTick -> LOAD = 48 * (pwmLowTime * 1000);  //8.75ms
         SysTick -> VAL = 0;
         SysTick -> CTRL = 0x00000005;
         while (!(SysTick -> CTRL & 0x00010000));
     return;
}